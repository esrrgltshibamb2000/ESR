const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database(path.join(__dirname, 'votes.db'));

app.use(cors());
app.use(bodyParser.json());

// Create tables
db.run(`CREATE TABLE IF NOT EXISTS voters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE
)`);
db.run(`CREATE TABLE IF NOT EXISTS votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT,
  candidate TEXT,
  voter_name TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Health check
app.get('/health', (req, res) => res.json({ ok: true }));

// Cast vote
app.post('/vote', (req, res) => {
  const { name, directeur, service } = req.body || {};
  if(!name || !directeur || !service){
    return res.status(400).json({ error: 'Données manquantes' });
  }
  db.get('SELECT * FROM voters WHERE name = ?', [name], (err, row) => {
    if(err) return res.status(500).json({ error: 'DB error' });
    if(row) return res.status(400).json({ error: '❌ Vous avez déjà voté !' });

    db.serialize(() => {
      db.run('INSERT INTO voters (name) VALUES (?)', [name]);
      db.run('INSERT INTO votes (category, candidate, voter_name) VALUES (?, ?, ?)', ['directeur', directeur, name]);
      db.run('INSERT INTO votes (category, candidate, voter_name) VALUES (?, ?, ?)', ['service', service, name], (e)=>{
        if(e) return res.status(500).json({ error: 'DB error' });
        return res.json({ message: '✅ Vote enregistré avec succès !' });
      });
    });
  });
});

// Results
app.get('/results', (req, res) => {
  db.all('SELECT category, candidate, COUNT(*) AS total FROM votes GROUP BY category, candidate', (err, rows) => {
    if(err) return res.status(500).json({ error: 'DB error' });
    res.json(rows || []);
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 API prête sur http://localhost:${PORT}`));
