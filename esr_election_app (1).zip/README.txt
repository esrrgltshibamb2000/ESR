# ESR Élections – Déploiement rapide

## Frontend (site de vote)
- Fichier : `frontend/index.html`
- Hébergez sur **Netlify**, **GitHub Pages** ou **Vercel**.
- Ouvrez la page, mettez l’URL de l’API (ex: `https://votre-api.onrender.com`) dans le champ **API**, cliquez sur **Enregistrer API**.

## Backend (API Node.js + SQLite)
1. Allez dans `backend/`
2. Installez les dépendances : `npm install`
3. Lancez en local : `npm start` (API sur `http://localhost:3000`)
4. Déployez sur **Render**, **Railway** ou **Heroku** (Node 18+, persistance de fichier activée si possible).

### Routes
- `POST /vote` `{ name, directeur, service }` → enregistre un vote (1 par personne)
- `GET /results` → renvoie les résultats agrégés
- `GET /health` → statut

## Liste des candidats
- **Directeur de Construction** : Ir Joël Ndona, Ir Parfait Kukambisa, Ir Enock Toussaint
- **Service Étude & Conception** : Ir Tonny Achema, Ar Bibiane Bawota

## Anti double-vote
Basé sur le champ `name` (nom / numéro). Mettez une consigne claire aux votants : utiliser le même identifiant unique.

---

© ESR
